




function Toplama() 
{
   
    
Sayı1=parseInt(document.getElementById("Sayı10").value);
Sayı2=parseInt(document.getElementById("Sayı11").value);
sonuc=Sayı1+Sayı2;
document.getElementById("sonuc1").innerHTML=sonuc;
}
function Çıkarma() 
{

Sayı1=parseInt(document.getElementById("Sayı10").value);
Sayı2=parseInt(document.getElementById("Sayı11").value);
sonuc=Sayı1-Sayı2;
document.getElementById("sonuc1").innerHTML=sonuc;
}
function Çarpma() 
{

    Sayı1=parseInt(document.getElementById("Sayı10").value);
    Sayı2=parseInt(document.getElementById("Sayı11").value);
    sonuc=Sayı1*Sayı2;
    document.getElementById("sonuc1").innerHTML=sonuc;
}
function Bölme() 
{

Sayı1=parseInt(document.getElementById("Sayı10").value);
Sayı2=parseInt(document.getElementById("Sayı11").value);
sonuc=Sayı1/Sayı2;
document.getElementById("sonuc1").innerHTML=sonuc;
}